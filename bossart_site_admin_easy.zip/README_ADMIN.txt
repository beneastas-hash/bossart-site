COMMENT UTILISER L'ADMIN

1. Mettez ce site sur Netlify avec GitHub.
2. Dans Netlify: Identity -> Enable Identity.
3. Dans Netlify: Identity -> Services -> Git Gateway -> Enable Git Gateway.
4. Ouvrez votre site: /admin
   Exemple: https://votre-site.netlify.app/admin
5. Connectez-vous.
6. Cliquez sur "Site BossArt" -> "Contenu du site".
7. Changez les textes ou ajoutez/remplacez les photos.
8. Cliquez sur "Publish".

Important:
L'administration ne fonctionne pas juste en ouvrant index.html sur votre téléphone.
Il faut Netlify + GitHub pour que les photos puissent être sauvegardées.
